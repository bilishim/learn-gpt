
import argparse, os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
from ece.trainer import train_multitask

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--save", type=str, default="ckpt.pt")
    ap.add_argument("--device", type=str, default="cpu")
    args = ap.parse_args()
    train_multitask(data_path=args.data, save_path=args.save, epochs=args.epochs, device=args.device)

if __name__ == "__main__":
    main()
