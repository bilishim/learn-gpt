
import json, random
from pathlib import Path
import argparse

OPS = ["instead","else","because","but","perhaps","like","as_much_as","even"]

def ensure_missing_in_rationale(required, choice, rationale, candidates):
    miss = [t for t in required if isinstance(t, str) and t.startswith("MISSING(")]
    if not miss:
        return choice, rationale
    miss_set = set(miss)
    def pick_safe(fallbacks):
        for fb in fallbacks:
            if fb in candidates: return fb
        return candidates[0]
    if "MISSING(milk)" in miss_set:
        if isinstance(choice, str) and ("latte" in choice.lower() or "cappuccino" in choice.lower()):
            choice = "americano" if "americano" in candidates else pick_safe([c for c in candidates if "latte" not in c and "cappuccino" not in c])
    if "MISSING(ice)" in miss_set:
        if isinstance(choice, str) and ("iced" in choice.lower() or "lemonade" in choice.lower()):
            if "lemonade_low_ice" in candidates:
                choice = "lemonade_low_ice"
            else:
                non_iced = [c for c in candidates if ("iced" not in c.lower())]
                if non_iced: choice = non_iced[0]
    miss_str = ", ".join(miss)
    if "MISSING(" not in rationale:
        rationale = f"{rationale} (refs: {miss_str})"
    else:
        for m in miss:
            if m not in rationale:
                rationale = f"{rationale}; {m}"
    return choice, rationale

def feasible_set(required, candidates):
    req = " ".join(required).lower()
    feas = []
    for c in candidates:
        cl = c.lower() if isinstance(c,str) else str(c).lower()
        ok = True
        if "missing(milk)" in req and ("latte" in cl or "cappuccino" in cl):
            ok = False
        if "missing(ice)" in req and ("iced" in cl or ("lemonade" in cl and "lemonade_low_ice" not in cl)):
            ok = False
        feas.append((c, ok))
    return [c for (c,ok) in feas if ok] or candidates  # fallback: allow all

def sample_case(idx:int, hot:bool, queue:str, child:bool, milk:int, ice:int, machine_ok:bool):
    env = {"temperature_c": random.randint(28,36) if hot else random.randint(8,18),
           "queue_length": {"short": random.randint(0,3), "medium": random.randint(4,7), "long": random.randint(8,12)}[queue],
           "time_of_day": random.choice(["morning","noon","afternoon"])}
    agent = {"age_group": "child" if child else "adult", "impatience": round(random.uniform(0.1,0.7),2)}
    system = {"inventory": {"milk": milk, "beans": random.randint(60,140), "ice": ice, "lemon": random.randint(6,16)}}
    if not machine_ok: system["devices"] = {"espresso_machine": "down"}

    event = {"when":"customer requests a drink","if":"requirements available","then":"prepare suitable drink","so":"customer is satisfied","so_type": random.choice(["continue","causal_trigger"])}

    required = []; tools = []
    pool = ["latte","americano","lemonade","lemonade_low_ice","iced_americano","refund_token","water"]
    candidates = random.sample(pool, k=random.randint(3,4))
    if hot and "lemonade_low_ice" not in candidates: candidates[0] = "lemonade_low_ice"
    if not hot and "latte" not in candidates: candidates[0] = "latte"

    if "latte" in candidates:
        tools.append("espresso_machine")
        if milk <= 0: required.append("MISSING(milk)")
        required += ["beans","cup"]
        if not machine_ok: tools = ["MISSING(espresso_machine)"]

    if "lemonade" in candidates or "lemonade_low_ice" in candidates or "iced_americano" in candidates:
        required += ["lemon","ice","cup"]
        if ice < 5 and random.random() < 0.5:
            required = ["lemon","MISSING(ice)","cup"]
        tools.append("shaker")

    process = {"start":"order taken","steps":["prep"],"required": required if required else ["cup"],"tools": tools if tools else ["bar"],"how":"standard","goal":"serve fast and tasty","end":"served","result":"drink"}
    system_contract = {"body":["barista","inventory"],"environment":[("hot day" if hot else "cold day"), f"queue:{queue}"],"value_function":"profit+speed+satisfaction","beneficial":["time_ok"],"harmful":[h for h in (["stock_violation(milk)"] if milk<=0 else []) + (["stock_critical(ice)"] if ice<5 else [])],"lifecycle":"daily"}
    operators_active = random.sample(OPS, k=random.randint(1,3))

    # Build a feasible set and choose in a round-robin manner to balance labels
    feas = feasible_set(process["required"], candidates)
    feas_sorted = sorted(feas)  # stable ordering
    choice = feas_sorted[idx % len(feas_sorted)]
    # Rationale + fuzzy per condition (rough heuristics)
    if "MISSING(milk)" in process["required"] and ("latte" in " ".join(candidates).lower()):
        rationale = "because MISSING(milk) prevents milk-based drinks; selecting an alternative"
        fuzzy = {"utility": 0.78, "constraint_fit": 1.0, "satisfaction": 0.72}
    elif not machine_ok and ("latte" in " ".join(candidates).lower()):
        rationale = "because espresso_machine is down; avoiding latte workflow"
        fuzzy = {"utility": 0.70, "constraint_fit": 1.0, "satisfaction": 0.65}
    elif hot and any(x in feas for x in ["lemonade_low_ice","iced_americano"]):
        rationale = "because hot weather favors cold options with responsible ice usage"
        fuzzy = {"utility": 0.72, "constraint_fit": 0.9, "satisfaction": 0.7}
    elif agent["age_group"] == "child" and "lemonade" in feas:
        rationale = "because child preference favors sweet cold drinks"
        fuzzy = {"utility": 0.7, "constraint_fit": 1.0, "satisfaction": 0.9}
    else:
        rationale = "because it fits current constraints and value function"
        fuzzy = {"utility": 0.62, "constraint_fit": 0.85, "satisfaction": 0.68}

    choice, rationale = ensure_missing_in_rationale(process["required"], choice, rationale, candidates)

    sample = {
        "id": f"GEN-{idx:04d}",
        "context": {"environment": env, "agent": agent, "system": system},
        "contracts": {"event": event, "process": process, "system": system_contract},
        "candidates": candidates,
        "operators_active": operators_active,
        "labels": {"policy_text": f"offer {choice.replace('_',' ')}", "choice": choice, "rationale_text": rationale, "fuzzy": fuzzy}
    }
    return sample

def build(n=600, seed=777, out_train="data/train/contracts_train.jsonl", out_val="data/val/contracts_val.jsonl", out_test="data/test/contracts_test.jsonl"):
    random.seed(seed)
    items = []
    combos = []
    for hot in [True, False]:
        for queue in ["short","medium","long"]:
            for child in [True, False]:
                for milk in [0, 10]:
                    for ice in [2, 8, 20]:
                        for machine_ok in [True, False]:
                            combos.append((hot, queue, child, milk, ice, machine_ok))
    random.shuffle(combos)
    total = min(n, len(combos))
    for i in range(total):
        items.append(sample_case(i+1, *combos[i]))

    tr = int(len(items)*0.8); va = int(len(items)*0.1)
    train, val, test = items[:tr], items[tr:tr+va], items[tr+va:]
    for path, arr in [(out_train, train), (out_val, val), (out_test, test)]:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            for s in arr:
                f.write(json.dumps(s) + "\n")
    print(f"Wrote: {out_train} ({len(train)})  {out_val} ({len(val)})  {out_test} ({len(test)})")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=600)
    ap.add_argument("--seed", type=int, default=777)
    ap.add_argument("--out-train", type=str, default="data/train/contracts_train.jsonl")
    ap.add_argument("--out-val", type=str, default="data/val/contracts_val.jsonl")
    ap.add_argument("--out-test", type=str, default="data/test/contracts_test.jsonl")
    args = ap.parse_args()
    build(n=args.n, seed=args.seed, out_train=args.out_train, out_val=args.out_val, out_test=args.out_test)
