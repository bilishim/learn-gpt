
import argparse, json, os, sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from pathlib import Path
from ece.simulate import load_model, infer_one

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True, help="Path to trained checkpoint (*.pt)")
    ap.add_argument("--data", required=True, help="Path to JSONL scenarios")
    ap.add_argument("--device", type=str, default="cpu")
    ap.add_argument("--sample", action="store_true", help="Use sampling instead of argmax")
    ap.add_argument("--temperature", type=float, default=1.3, help="Sampling temperature")
    ap.add_argument("--no-mask", action="store_true", help="Disable feasibility mask")
    args = ap.parse_args()

    tok, model, cand_enc, head_choice, head_val, head_con, head_sat, cfg = load_model(args.ckpt, device=args.device)
    items = [json.loads(l) for l in Path(args.data).read_text(encoding="utf-8").splitlines() if l.strip()]

    for s in items:
        print("=" * 80)
        print("Scenario ID:", s.get("id","N/A"))
        print("Scenario JSON:")
        print(json.dumps(s, indent=2))
        print("-" * 80)

        out = infer_one(
            s, tok, model, cand_enc, head_choice, head_val, head_con, head_sat,
            device=args.device, sample_choice=args.sample, temperature=args.temperature, use_mask=(not args.no_mask)
        )
        print("Model decision:")
        print(json.dumps(out, indent=2))
        print("=" * 80)

if __name__ == "__main__":
    main()
