
import json, re
from pathlib import Path
import argparse

OPS = set(["instead","else","because","but","perhaps","like","as_much_as","even"])

def validate(path:str) -> int:
    errors = 0
    lines = [l for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]
    for i, line in enumerate(lines, 1):
        try:
            s = json.loads(line)
        except Exception as e:
            print(f"[{i}] JSON error: {e}"); errors += 1; continue

        cand = s.get("candidates", [])
        choice = s.get("labels", {}).get("choice")
        if choice not in cand:
            print(f"[{i}] choice not in candidates: {choice} not in {cand}"); errors += 1

        txt = json.dumps(s, ensure_ascii=False)
        if any(ch in txt for ch in "ğıüşçöİĞÜŞÇÖ"):
            print(f"[{i}] non-English characters detected (heuristic)"); errors += 1

        ops = s.get("operators_active", [])
        for op in ops:
            if op not in OPS:
                print(f"[{i}] unknown operator '{op}'"); errors += 1

        process = s.get("contracts",{}).get("process",{})
        miss_tokens = []
        for r in process.get("required", []):
            if isinstance(r, str) and r.startswith("MISSING("):
                miss_tokens.append(r)
        for t in miss_tokens:
            token = t.strip(',}\"\' ')
            if not re.match(r"^MISSING\([a-zA-Z0-9_]+\)$", token):
                print(f"[{i}] malformed MISSING token: {t}"); errors += 1

        if miss_tokens:
            rat = s.get("labels",{}).get("rationale_text","")
            if "MISSING(" not in rat:
                print(f"[{i}] rationale_text should reference MISSING(...) but doesn't"); errors += 1

    if errors == 0: print(f"OK: {path}")
    else: print(f"Found {errors} issues in {path}")
    return errors

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    args = ap.parse_args()
    validate(args.data)
