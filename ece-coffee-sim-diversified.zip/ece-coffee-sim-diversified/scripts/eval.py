
import argparse, json, os, sys
from pathlib import Path
import numpy as np

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))
from ece.simulate import load_model, infer_one

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--data", required=True)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--sample", action="store_true")
    ap.add_argument("--temperature", type=float, default=1.3)
    ap.add_argument("--no-mask", action="store_true")
    args = ap.parse_args()

    tok, model, cand_enc, head_choice, head_val, head_con, head_sat, cfg = load_model(args.ckpt, device=args.device)
    items = [json.loads(l) for l in Path(args.data).read_text(encoding="utf-8").splitlines() if l.strip()]

    n = 0; correct = 0; mse_u=[]; mse_c=[]; mse_s=[]
    for s in items:
        out = infer_one(
            s, tok, model, cand_enc, head_choice, head_val, head_con, head_sat,
            device=args.device, sample_choice=args.sample, temperature=args.temperature, use_mask=(not args.no_mask)
        )
        if "labels" in s and "choice" in s["labels"]:
            n += 1
            if out["choice"] == s["labels"]["choice"]:
                correct += 1
            if "fuzzy" in s["labels"]:
                t = s["labels"]["fuzzy"]
                mse_u.append((out["fuzzy"]["utility"] - t["utility"])**2)
                mse_c.append((out["fuzzy"]["constraint_fit"] - t["constraint_fit"])**2)
                mse_s.append((out["fuzzy"]["satisfaction"] - t["satisfaction"])**2)

    acc = correct/max(n,1)
    print(f"Choice accuracy: {acc:.3f} on {n} labeled items")
    if mse_u:
        print(f"MSE utility={np.mean(mse_u):.4f}  constraint_fit={np.mean(mse_c):.4f}  satisfaction={np.mean(mse_s):.4f}")

if __name__ == "__main__":
    main()
