# ECE — Emergent Clause Engine (Coffee Simulator, DIVERSIFIED)
Transformer + Attention simulator with **diverse outcomes**:
- `simulate.py` supports `--sample` and `--temperature` (stochastic choice)
- Feasibility mask is **ON by default** (down-weights impossible options)
- Balanced dataset generator to avoid majority-class collapse

## Quickstart (Windows)
```bat
pip install -r requirements.txt

:: (optional) regenerate a balanced dataset
python scripts\generate_dataset.py --n 600 --seed 777

:: validate dataset
python scripts\validate_dataset.py --data data\train\contracts_train.jsonl

:: train
python scripts\train.py --data data\train\contracts_train.jsonl --epochs 16 --save ckpt.pt

:: evaluate
python scripts\eval.py --ckpt ckpt.pt --data data\test\contracts_test.jsonl

:: simulate (stochastic sampling)
python scripts\simulate.py --ckpt ckpt.pt --data data\val\contracts_val.jsonl --sample --temperature 1.3
```
Tip: for deterministic runs, omit `--sample` (argmax). Use `--no-mask` to disable feasibility mask.
