
from typing import List
from collections import Counter

class SimpleTokenizer:
    def __init__(self, specials: List[str] = None):
        self.stoi = {}
        self.itos = []
        for t in (specials or ["<pad>","<unk>"]):
            self.add(t)
    def add(self, tok: str) -> int:
        if tok not in self.stoi:
            self.stoi[tok] = len(self.itos); self.itos.append(tok)
        return self.stoi[tok]
    def encode(self, text: str) -> List[int]:
        return [self.stoi.get(t, self.stoi["<unk>"]) for t in text.lower().split()]
    def build_from_corpus(self, lines: List[str], min_freq: int = 1):
        c = Counter()
        for line in lines: c.update(line.lower().split())
        for tok, cnt in c.items():
            if cnt >= min_freq: self.add(tok)
