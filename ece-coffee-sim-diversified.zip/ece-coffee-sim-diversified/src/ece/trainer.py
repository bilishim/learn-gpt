
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from .backbone import ECETransformer
from .heads import CandidateEncoder, ChoiceHead, ValueHead, ConstraintHead, SatisfactionHead
from .tokenizer import SimpleTokenizer
from .data_utils import CoffeeDataset, collate_fn

def train_multitask(data_path: str, save_path: str = "ckpt.pt", epochs: int = 10, d_model: int = 128, nhead: int = 4, num_layers: int = 3, lr: float = 2e-3, batch_size: int = 8, device: str = "cpu"):
    tok = SimpleTokenizer(["<pad>","<unk>"])
    ds = CoffeeDataset(data_path, tok, build_vocab=True)
    if len(ds) == 0:
        raise ValueError("Dataset must include labeled items with 'labels.choice' and 'fuzzy'.")
    dl = DataLoader(ds, batch_size=batch_size, shuffle=True, collate_fn=collate_fn)

    model = ECETransformer(vocab_size=len(tok.itos), d_model=d_model, nhead=nhead, num_layers=num_layers).to(device)
    cand_enc = CandidateEncoder(model.tok).to(device)
    head_choice = ChoiceHead(d_model).to(device)
    head_val = ValueHead(d_model).to(device)
    head_con = ConstraintHead(d_model).to(device)
    head_sat = SatisfactionHead(d_model).to(device)

    params = list(model.parameters()) + list(head_choice.parameters()) + list(head_val.parameters()) + list(head_con.parameters()) + list(head_sat.parameters())
    opt = optim.Adam(params, lr=lr)
    ce = nn.CrossEntropyLoss(); mse = nn.MSELoss()

    for ep in range(1, epochs+1):
        model.train(); head_choice.train(); head_val.train(); head_con.train(); head_sat.train()
        tot_choice=tot_val=tot_con=tot_sat=0.0; steps=0
        for token_ids, role_ids, cand_ids_batch, y_choice, y_reg in dl:
            token_ids = token_ids.to(device); role_ids = role_ids.to(device)
            y_choice = y_choice.to(device)
            y_val, y_con, y_sat = y_reg[:,0].to(device), y_reg[:,1].to(device), y_reg[:,2].to(device)

            pooled = model(token_ids, role_ids)
            logits_list = []
            for i, cand_ids in enumerate(cand_ids_batch):
                cand_embs = cand_enc([c.to(device) for c in cand_ids])
                logits_list.append(head_choice(pooled[i:i+1], cand_embs))
            maxC = max(l.shape[1] for l in logits_list)
            padded = [torch.cat([l, torch.full((1,maxC-l.shape[1]), -1e9, device=l.device)], dim=1) if l.shape[1]<maxC else l for l in logits_list]
            logits = torch.cat(padded, dim=0)

            loss_choice = ce(logits, y_choice)
            loss_val = mse(head_val(pooled), y_val)
            loss_con = mse(head_con(pooled), y_con)
            loss_sat = mse(head_sat(pooled), y_sat)
            loss = loss_choice + 0.5*(loss_val + loss_con + loss_sat)

            opt.zero_grad(); loss.backward(); opt.step()
            tot_choice += loss_choice.item(); tot_val += loss_val.item(); tot_con += loss_con.item(); tot_sat += loss_sat.item(); steps += 1
        print(f"[epoch {ep}] choice={tot_choice/steps:.4f} val={tot_val/steps:.4f} con={tot_con/steps:.4f} sat={tot_sat/steps:.4f}")

    torch.save({
        "vocab": tok.itos,
        "model_state": model.state_dict(),
        "choice_state": head_choice.state_dict(),
        "val_state": head_val.state_dict(),
        "con_state": head_con.state_dict(),
        "sat_state": head_sat.state_dict(),
        "cfg": {"d_model": d_model, "nhead": nhead, "num_layers": num_layers}
    }, save_path)
    print(f"Saved checkpoint -> {save_path}")
