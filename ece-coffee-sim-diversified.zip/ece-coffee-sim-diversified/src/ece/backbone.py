
from typing import Optional
import math
import torch
import torch.nn as nn
import torch.nn.functional as F

NUM_ROLES = 5  # 0=pad,1=event,2=process,3=system,4=agent

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 2048):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div)
        pe[:, 1::2] = torch.cos(position * div)
        self.register_buffer("pe", pe.unsqueeze(0))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[:, :x.size(1), :]

class MultiheadSelfAttention(nn.Module):
    def __init__(self, d_model: int, nhead: int, dropout: float = 0.1):
        super().__init__()
        assert d_model % nhead == 0
        self.nhead = nhead
        self.d_head = d_model // nhead
        self.qkv = nn.Linear(d_model, 3*d_model, bias=False)
        self.o = nn.Linear(d_model, d_model, bias=False)
        self.drop = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, attn_bias: Optional[torch.Tensor] = None) -> torch.Tensor:
        B,T,D = x.shape
        qkv = self.qkv(x)
        q,k,v = qkv.chunk(3, dim=-1)
        def split(t): return t.view(B, T, self.nhead, self.d_head).transpose(1,2)
        q = split(q); k = split(k); v = split(v)
        logits = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(self.d_head)
        if attn_bias is not None: logits = logits + attn_bias
        attn = F.softmax(logits, dim=-1)
        attn = self.drop(attn)
        out = torch.matmul(attn, v).transpose(1,2).contiguous().view(B, T, D)
        return self.o(out)

class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model: int, nhead: int, dim_ff: int = 256, dropout: float = 0.1):
        super().__init__()
        self.mha = MultiheadSelfAttention(d_model, nhead, dropout)
        self.ln1 = nn.LayerNorm(d_model)
        self.ff = nn.Sequential(
            nn.Linear(d_model, dim_ff), nn.ReLU(),
            nn.Linear(dim_ff, d_model), nn.Dropout(dropout)
        )
        self.ln2 = nn.LayerNorm(d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.mha(self.ln1(x))
        x = x + self.ff(self.ln2(x))
        return x

class ECETransformer(nn.Module):
    def __init__(self, vocab_size: int, d_model: int = 128, nhead: int = 4, num_layers: int = 3, dim_ff: int = 256, dropout: float = 0.1):
        super().__init__();
        self.tok = nn.Embedding(vocab_size, d_model)
        self.role = nn.Embedding(NUM_ROLES, d_model)
        self.pos = PositionalEncoding(d_model)
        self.layers = nn.ModuleList([TransformerEncoderLayer(d_model, nhead, dim_ff, dropout) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(d_model)

    def forward(self, token_ids: torch.Tensor, role_ids: torch.Tensor) -> torch.Tensor:
        x = self.tok(token_ids) + self.role(role_ids)
        x = self.pos(x)
        for layer in self.layers:
            x = layer(x)
        x = self.norm(x)
        return x[:, 0]  # CLS pooling
