
import json
from typing import Dict, Any
import torch

from .backbone import ECETransformer
from .heads import CandidateEncoder, ChoiceHead, ValueHead, ConstraintHead, SatisfactionHead
from .tokenizer import SimpleTokenizer

def load_model(ckpt_path: str, device: str = "cpu"):
    ckpt = torch.load(ckpt_path, map_location=device)
    itos = ckpt["vocab"]
    tok = SimpleTokenizer()
    tok.itos = itos; tok.stoi = {t:i for i,t in enumerate(itos)}
    cfg = ckpt["cfg"]
    model = ECETransformer(vocab_size=len(itos), **cfg).to(device); model.load_state_dict(ckpt["model_state"])
    choice = ChoiceHead(cfg["d_model"]).to(device); choice.load_state_dict(ckpt["choice_state"])
    val = ValueHead(cfg["d_model"]).to(device); val.load_state_dict(ckpt["val_state"])
    con = ConstraintHead(cfg["d_model"]).to(device); con.load_state_dict(ckpt["con_state"])
    sat = SatisfactionHead(cfg["d_model"]).to(device); sat.load_state_dict(ckpt["sat_state"])
    cand_enc = CandidateEncoder(model.tok).to(device)
    for m in [model, choice, val, con, sat]: m.eval()
    return tok, model, cand_enc, choice, val, con, sat, cfg

def serialize_for_tokens(s: Dict[str, Any]) -> str:
    ev = s["contracts"]["event"]
    pr = s["contracts"]["process"]
    sy = s["contracts"]["system"]
    ctx = s["context"]
    parts = [
        f"when {ev['when']} if {ev['if']} then {ev['then']} so {ev['so']}",
        "process " + " ".join(pr.get("steps", [])),
        "required " + " ".join(pr.get("required", [])),
        "tools " + " ".join(pr.get("tools", [])),
        "system " + " ".join(sy.get("body", [])) + " env " + " ".join(sy.get("environment", [])),
        "env " + str(ctx.get("environment", {})),
        "agent " + str(ctx.get("agent", {})),
        "sys " + str(ctx.get("system", {}))
    ]
    return " | ".join(parts)

def apply_feasibility_mask(logits, sample):
    required = sample["contracts"]["process"].get("required", [])
    req_txt = " ".join(required).lower()
    cand_txts = [c.lower() if isinstance(c,str) else str(c).lower() for c in sample["candidates"]]
    mask = torch.zeros_like(logits)
    for i, ct in enumerate(cand_txts):
        penalize = False
        if "missing(milk)" in req_txt and ("latte" in ct or "cappuccino" in ct):
            penalize = True
        if "missing(ice)" in req_txt and ("iced" in ct or ("lemonade" in ct and "lemonade_low_ice" not in ct)):
            penalize = True
        mask[0, i] = -8.0 if penalize else 0.0
    return logits + mask

def infer_one(sample: Dict[str, Any], tok: SimpleTokenizer, model: ECETransformer, cand_enc, head_choice, head_val, head_con, head_sat, device="cpu", sample_choice=False, temperature=1.3, use_mask=True):
    state = {
        "inventory": sample.get("context", {}).get("system", {}).get("inventory", {}),
        "queue_length": sample.get("context", {}).get("environment", {}).get("queue_length", None),
        "time_of_day": sample.get("context", {}).get("environment", {}).get("time_of_day", None)
    }
    print("Initial STATE:", state)

    text = serialize_for_tokens(sample)
    token_ids = torch.tensor(tok.encode(text), dtype=torch.long).unsqueeze(0).to(device)
    role_ids = torch.zeros_like(token_ids)

    cand_texts = [c if isinstance(c, str) else str(c) for c in sample["candidates"]]
    cand_ids = [torch.tensor(tok.encode(ct), dtype=torch.long) for ct in cand_texts]
    cand_embs = cand_enc([c.to(device) for c in cand_ids])

    with torch.no_grad():
        pooled = model(token_ids, role_ids)
        logits = head_choice(pooled, cand_embs)
        if use_mask:
            logits = apply_feasibility_mask(logits, sample)
        if sample_choice:
            logits_T = logits / float(temperature)
            probs_T = torch.softmax(logits_T, dim=-1).squeeze(0)
            idx = int(torch.multinomial(probs_T, num_samples=1).item())
        else:
            probs = torch.softmax(logits, dim=-1).squeeze(0)
            idx = int(torch.argmax(probs).item())
        choice = sample["candidates"][idx]
        u = float(torch.sigmoid(head_val(pooled)).item())
        cfit = float(torch.sigmoid(head_con(pooled)).item())
        s = float(torch.sigmoid(head_sat(pooled)).item())

    inv = state.get("inventory", {})
    if isinstance(choice, str):
        lc = choice.lower()
        if "latte" in lc and "milk" in inv and inv["milk"]:
            inv["milk"] = max(0, inv["milk"] - 1)
        if "lemonade" in lc and "lemon" in inv and inv["lemon"]:
            inv["lemon"] = max(0, inv["lemon"] - 1)
        if "iced" in lc and "ice" in inv and inv["ice"]:
            inv["ice"] = max(0, inv["ice"] - 2)

    print("Chosen action:", choice)
    print("STATE after action:", state)

    rationale = "because it best fits current constraints and value function"
    required = sample["contracts"]["process"].get("required", [])
    missing_fields = [r for r in required if isinstance(r, str) and r.startswith("MISSING(")]
    if missing_fields:
        fields = ", ".join(missing_fields)
        rationale = f"because required fields are missing ({fields}), selecting a feasible alternative"

    return {
        "policy_text": f"Offer {choice.replace('_',' ')}",
        "choice": choice,
        "fuzzy": {"utility": round(u,2), "constraint_fit": round(cfit,2), "satisfaction": round(s,2)},
        "rationale_text": rationale
    }
