
import json
from pathlib import Path
from typing import Any, Dict
import torch
from torch.utils.data import Dataset

ROLE_PAD=0; ROLE_EVENT=1; ROLE_PROCESS=2; ROLE_SYSTEM=3; ROLE_AGENT=4

def serialize_sample_context(s: Dict[str, Any]) -> str:
    ev = s["contracts"]["event"]
    pr = s["contracts"]["process"]
    sy = s["contracts"]["system"]
    ctx = s["context"]
    parts = [
        f"when {ev['when']} if {ev['if']} then {ev['then']} so {ev['so']}",
        "process " + " ".join(pr.get("steps", [])),
        "required " + " ".join(pr.get("required", [])),
        "tools " + " ".join(pr.get("tools", [])),
        "system " + " ".join(sy.get("body", [])) + " env " + " ".join(sy.get("environment", [])),
        "env " + str(ctx.get("environment", {})),
        "agent " + str(ctx.get("agent", {})),
        "sys " + str(ctx.get("system", {}))
    ]
    return " | ".join(parts)

class CoffeeDataset(Dataset):
    def __init__(self, path: str, tokenizer, build_vocab: bool = False):
        self.items = [json.loads(l) for l in Path(path).read_text(encoding="utf-8").splitlines() if l.strip()]
        self.tok = tokenizer
        if build_vocab:
            corpus = [serialize_sample_context(s) for s in self.items]
            for s in self.items:
                corpus += [c if isinstance(c, str) else str(c) for c in s.get("candidates", [])]
            self.tok.build_from_corpus(corpus)
        self.labeled = [s for s in self.items if s.get("labels") and s["labels"].get("choice") in s.get("candidates", [])]
    def __len__(self): return len(self.labeled)
    def __getitem__(self, idx):
        s = self.labeled[idx]
        x_text = serialize_sample_context(s)
        x_ids = self.tok.encode(x_text)
        role_ids = [ROLE_SYSTEM]*len(x_ids)
        cand_ids = [torch.tensor(self.tok.encode(c if isinstance(c, str) else str(c)), dtype=torch.long) for c in s["candidates"]]
        y_choice = s["candidates"].index(s["labels"]["choice"])
        y_val = s["labels"]["fuzzy"]["utility"]
        y_con = s["labels"]["fuzzy"]["constraint_fit"]
        y_sat = s["labels"]["fuzzy"]["satisfaction"]
        return (torch.tensor(x_ids, dtype=torch.long),
                torch.tensor(role_ids, dtype=torch.long),
                cand_ids,
                torch.tensor(y_choice, dtype=torch.long),
                torch.tensor([y_val, y_con, y_sat], dtype=torch.float))

def collate_fn(batch):
    maxT = max(len(x[0]) for x in batch)
    token_ids=[]; role_ids=[]; cand_ids_batch=[]; y_choice=[]; y_reg=[]
    for (tok, role, cand_ids, y_c, y_r) in batch:
        pad = maxT - len(tok)
        token_ids.append(torch.cat([tok, torch.zeros(pad, dtype=torch.long)], dim=0))
        role_ids.append(torch.cat([role, torch.zeros(pad, dtype=torch.long)], dim=0))
        cand_ids_batch.append(cand_ids)
        y_choice.append(y_c)
        y_reg.append(y_r)
    return (torch.stack(token_ids), torch.stack(role_ids), cand_ids_batch, torch.stack(y_choice), torch.stack(y_reg))
