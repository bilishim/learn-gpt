
from typing import List
import torch
import torch.nn as nn

class MLP(nn.Module):
    def __init__(self, d_in: int, d_hidden: int, d_out: int, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, d_hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(d_hidden, d_out)
        )
    def forward(self, x): return self.net(x)

class CandidateEncoder(nn.Module):
    def __init__(self, token_emb: nn.Embedding):
        super().__init__()
        self.token_emb = token_emb
    def forward(self, cand_token_ids: List[torch.Tensor]) -> torch.Tensor:
        embs = []
        for ids in cand_token_ids:
            e = self.token_emb(ids)  # (T,D)
            embs.append(e.mean(dim=0))
        return torch.stack(embs, dim=0)  # (C,D)

class ChoiceHead(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.scorer = MLP(d_model*2, d_model, 1)
    def forward(self, pooled_ctx: torch.Tensor, cand_embs: torch.Tensor) -> torch.Tensor:
        B,D = pooled_ctx.shape
        C,_ = cand_embs.shape
        ctx = pooled_ctx.unsqueeze(1).expand(B, C, D)
        x = torch.cat([ctx, cand_embs.unsqueeze(0).expand(B, C, D)], dim=-1)
        logits = self.scorer(x).squeeze(-1)
        return logits

class ValueHead(nn.Module):
    def __init__(self, d_model: int): super().__init__(); self.readout = MLP(d_model, d_model, 1)
    def forward(self, pooled_ctx): return self.readout(pooled_ctx).squeeze(-1)

class ConstraintHead(nn.Module):
    def __init__(self, d_model: int): super().__init__(); self.readout = MLP(d_model, d_model, 1)
    def forward(self, pooled_ctx): return self.readout(pooled_ctx).squeeze(-1)

class SatisfactionHead(nn.Module):
    def __init__(self, d_model: int): super().__init__(); self.readout = MLP(d_model, d_model, 1)
    def forward(self, pooled_ctx): return self.readout(pooled_ctx).squeeze(-1)
